title: OpenStack镜像服务Glance基本操作
date: '2019-12-10 17:13:19'
updated: '2019-12-10 20:18:47'
tags: [OpenStack, 云计算]
permalink: /articles/2019/12/10/1575969199194.html
---
![](https://img.hacpai.com/bing/20190503.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 一、Glance简介
 OpenStack镜像服务是IaaS的核心服务，它接受磁盘镜像或服务器镜像API请求，和来自终端用户或OpenStack计算组件的元数据定义。它也支持包括OpenStack对象存储在内的多种类型仓库上的磁盘镜像或服务器镜像存储。
 
 大量周期性进程运行于OpenStack镜像服务上以支持缓存。同步复制服务保证集群中的一致性和可用性。其它周期性进程包括
auditors, updaters, 和 reapers。

# 二、Glance安装与配置

环境介绍：

|节点名称 | host ip | OS|
|-------- | -----|-------|
|controller | 192.168.1.218 | Ubuntu16.04 64bit 8G|
|compute  | 192.168.1.174 | Ubuntu16.04 64bit 2G|

以下配置需要在controller节点上进行：
1、创建数据库并授权
```
$mysql -u root -p

mysql> create database glance default character set utf8;
mysql> grant all privileges on glance.* to 'glance'@'localhost' identified by 'GLANCE_DBPASS';
mysql> grant all privileges on glance.* to 'glance'@'%' identified by 'GLANCE_DBPASS';
mysql> exit;
```
使用glance用户的密码替换掉GLANCE_DBPASS
2、执行Openstack客户端脚本获取admin管理权限
```
$source admin-openrc
```

3、创建服务、用户和API端点
```
# 创建glance用户
$openstack user create --domain default --password-prompt glance

# 添加admin角色到glance用户和service项目上
$openstack role add --project service --user glance admin

# 创建glance服务实体
$openstack service create --name glance --description "OpenStack Image" image

# 创建镜像服务的API端点
$openstack endpoint create --region RegionOne image public http://controller:9292
$openstack endpoint create --region RegionOne image internal http://controller:9292
$openstack endpoint create --region RegionOne image admin http://controller:9292
```
4、安装软件包
```
$sudo apt-get install glance
```

5、编辑配置文件
a、编辑/etc/glance/glance-api.conf
```

[database]
connection = mysql+pymysql://glance:GLANCE_DBPASS@controller/glance

[keystone_authtoken]
auth_uri = http://controller:5000
auth_url = http://controller:35357
memcached_servers = controller:11211
auth_type = password
project_domain_name = default
user_domain_name = default
project_name = service
username = glancepassword = GLANCE_PASS

[paste_deploy]
flavor = keystone

[glance_store]
stores = file,http
default_store = file
filesystem_store_datadir = /var/lib/glance/images/

```

b、编辑/etc/glance/glance-registry.conf
```
[database]
connection = mysql+pymysql://glance:GLANCE_DBPASS@controller/glance


[keystone_authtoken]
auth_uri = http://controller:5000
auth_url = http://controller:35357
memcached_servers = controller:11211
auth_type = password
project_domain_name = default
user_domain_name = default
project_name = service
username = glance
password = GLANCE_PASS

[paste_deploy]
flavor = keystone

```

将 GLANCE_PASS 替换为你为认证服务中你为 glance 用户选择的密码。

在 [keystone_authtoken] 中注释或者删除其他选项

6、写入镜像服务数据库
```
$sudo su -s /bin/sh -c "glance-manage db_sync" glance
```

7、重启镜像服务
```
$sudo service glance-registry restart
$sudo service glance-api restart
```

8、验证安装是否成功
```
# 运行OpenStack客户端环境脚本admin-openrc
$source admin-openrc

# 下载镜像源
$ wget http://download.cirros-cloud.net/0.3.5/cirros-0.3.5-x86_64-disk.img

# 上传镜像
$openstack image create "cirros" --file cirros-0.3.5-x86_64-disk.img --disk-format qcow2 --container-format bare --public

# 确认镜像的上传并验证属性
$ openstack image list
```
若看到下图所示的输出，则说明镜像服务安装成功

![2fcc809c131c29f9a9328e969460673e.png](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA4wAAADECAYAAADUKa8+AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABg6SURBVHhe7d1LltvWtQbgOyc1PYtkFLXkngcQ90qdLGUEcrXdoTMDLTVlNTwCZwB5K1HeCS43QODsAx7wVUWKdH3/Wt+6KYJ4HaBQ5zdLt/6vExG5lfzvf1338WPX/fa3t+EPf+i6//xnc/BnTuznd79rH8clxTH861+bgzognz61t3Npf/pT1/31r+1l2THnNs8//9ne5jFifHflOY2niIhcJAqjiNxe/vGP6yhHu0SxjYJ7ycTk+3OPS1ybYxJjFMW6ta1LiWsVOaTQ/f3vw3tPyX//297msWI7S3lO4ykiIheJwigit5n4RC0+xWhNQj+n3//++NL0lPn3vz9faTz1vD/Xp6Oxz1xY4jha78vGMnRqnuKe3fep3HMaTxEROXsURhG57cQENUpaazJ6STFZjl/Bu/Sniq3EJ1B//GP7OM8hxv+xv1p46aIb4xOFZp59xxDLH5MYp9Z2j/G3v202tiPPZTxFROTsURhF5PYTJS3+7dYlJ8ij2Odf/rL71wQ/Vy4xJn/+89OdexSOc/86ZYzHrsIV59NaL4tftXxMHvvvDON+OyTPZTxFROSsURhF5KeTKI7xieMlPl2LfcRE+Ro+UdyVKA1RMFrn8Bhx/ueY6J+r/Mf2Yrv7ym38Wm1r/SxK0GMT905r24eIX2s9NM9lPEVE5GxRGEXkp5koSjGhfcryGNuKbcav+91aYmIfx/6YT5yiJMS/ObvE/2fLpzjeEOUq/iPCocU+3ndIuWr9+uWxifvolH/TGMd3bJ7DeIqIyFmiMIrITz8xaY2SE5/qxKdtMemNiXP827s8mY3/Ha/FsnhPvDfWiXUPnSDfQmJyHp/8xL+5jE934nzj3MexGMchCnIsj6IRnyZ+rjGI442Skq9d67rF8Uah/dzHe2zi/OI+i7GOc1i6FuO5Pfb/qdJPfTxFRORJozCKiIiIiIhIMwqjiIiIiIiINHNVhfHTp0/dDz/80L1//7778OEDAADARUQHiS4SnURKrqYwxoWJi/TVV191X3zxRffixQsAAICLiA4SXSQ6idJYcjWFMdp8XKDWxQMAALiE6CTRTWTI1RTGaPI+WQQAAD6n6CTRTWTI1RTG+L3h1gUDAAC4pOgmMkRhBAAASBTGEoURAAAgURhLFEYAAIBEYSxRGAEAABKFsURhBAAASBTGEoURAAAgURhLFEYAAIBEYSxRGAEAABKFsURhBAAASBTGEoURAAAgURhLFEYAAIBEYSxRGAEAABKFsURhBAAASBTGEoURAAAgURhLFEYAAIBEYSxRGAEAABKFsURhBAAASBTGEoURAAAgURhLFEYAAIBEYSxRGAEAABKFsURhnHv5uvv2V1+2lz1Xv/6x6z6+7163lh0i1l/nx183ll2N1937j/1hrvOxe//Lxntu4jwAAHgshbFEYRxFUfz22+Kbr7uftd539Ybi86Sl5lkUxtF33Y9PWhjPcD0AADgrhbFEYQw//7r75ttvuq9//qL78lffdq9fNt5zM66wMN6UHYXxJAojAMCtURhLFMZQFcbh/zbf15R/lXGdVKxef/+x+/j9d2l5XURiecmP3Xeb11/88n33cb2d97/ZLFqnKhyxfPN6n99819jemLTP+XrzErj5BG3MtM+qMEah6peW412Ux2b73D9+/37Y1nrb322O/eP3r6flOePr29sdU47nuzRuxxfdVmFcPo/eqdcDAICrpDCWKIwbP/vFN5tfR33dfdlY3jYUiVxm+rIyKwxj8eq/3izrS9j4v+dfjwUkvzcVn9jH8idWwzEd8olWtZ2+LC6UmWn/Q1k8ZNu17RI2jE28timg63OtxqcS75kVwul99bZjG/l6zL/eb/tY9y17qusBAMB1UBhLFMbKl93ro/4NY11keqncbRWgzSeHsawvPfOMpbAvjLNPHNPXQ9lap1mudhWUON46Y5mK41ksVn2Z7N+9UKT22S5aZWzKsmq8pn2OKetvF8bxfPMngSnNcVqyfaz7lp1+PQAAuEYKY4nCmMWvpvZF8Wfd198c8m8Zo0CcXhgXS8SewjgZS9VYNHvLBaUuWnVJ3FsYYx/9/hrHsdd20dpdGOO1fA6z9Wdlshx3nPtS2TvU9rEetmztyOsBAMB1UhhLFMZs+pMawyeN+wvjUAbqwlK+nhfGXMqGT6UWytehhbEXJaZe1i5/s2Ptt5m+3lUGx8K4/t/9cVeF6BDbRWtnYeyPrbx/GKvx692lsC/FRx9f9ojC2Dv0egAAcK0UxhKFMcz/pMZBZXEUBSElFcSh6KSkZaEvNyl1mVsqjEPxy9n69GpTBoekglN9Mvdj9359fLnIzI932m4qjPH1cNz7ilOYjU2fYb2dhXG9bjU2v3lfl8TqPIaU8zhgfJqWj3X3skdcDwAArpLCWKIwJvH/+OYp/6RGLkA8laGgVaVs16ejAABwJIWxRGFMnvpvMCqM5zB82pcLYz/Oj/o1VAAAKBTGEoXxjBTGM9n6lVSfLgIA8HQUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgr993qw7vu4WVrGcCJXj507z6suvvWsmfBs/Xuzbvuw+q+uQyA66MwliiMFZMa4AwURoVRYQS4KQpjicJYMakBzkBhVBgVRoCbojCWKIxr/Q/y9f63TD/cY7KTXn/70N1N6+9adtc9vE3LqgnjrmXbx7R6VZa9eLWqlr17c3fYMudx8rFe/jzOM+Ynn8eV3Tu3ch73q/x6MR3TWe6dU8/j6cd8vs7krM/WM907J12P2esT/2ES4NrF81qGKIyV+OHuBznwxHzC+OyfrX1R9QkjwM1QGEsUxopJDXAGCqPCqDAC3BSFsURhrJjUAGegMCqMCiPATVEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxRGAACARGEsURgBAAAShbFEYQQAAEgUxhKFEQAAIFEYSxTGSvxx6ef8x7WBs4g/3P/2obtrLXsWPFvjD/e/e3PXXAbA9VEYSxTGikkNcAYKo8KoMALcFIWxRGGsHD+puV996I89W72KZXfdw9vZstX91vrAM3BsYXy16p8ZuWDEs+Z2C8cphXH+DH3XPbxMy2OMTirhcSyzbV2AwghwW+JnjwxRGCun/1fw7cncMNkZymP5WmmEZ+iUwvh2XTDS8+i5Fca956swAnBGCmOJwlg5Z2Fci0njidsHbthJhfGhu1+XjPEZUj1j+mdJ+vRt3PZmPw/r9/afyL3avC/tO4rLtN7FnkfHPluH52e7YMW2xuNP0n+Mi7HKy/IY5tcH43HNi+Ts6/mYH/kf/xRGgNsSz3oZojBWzlwYtyYkwLNwYmG8S+ttP2OKWNY/azalJt43lKP186x/bfNci+3mojP/+mxOeLamglY/RzcO/YRxa+yXnsPz1+uvpzGu1jmcwghwWxTGEoWxcsKkZkNhBBZtlZY9Uhkai0r9jIlnSfq0a61flsrh9P7Za3md3jHHdbLTn63lXGfPzh2Fsf4UNeR9Lz2H56/XX0/bPLFgK4wAtyWe+TJEYaycPqk5qDCmiVt5H/CT94jC2K+7Lin5GdMXv1Rclsph67XHfEp2utOfraO+sM0/HW2NaX++qfil8x/ec1phnMR+ozgeWbQVRoDbojCWKIyVcxbG2Pb8PcCzEKXl1MLYP0vWZWP6N33Ds2V6lvSFqF0O568Nn5I9rrid5vRn6yjOpyqMW0Vwoy905fV+vep9rd/+CMMzenx9WK9VLMPx56MwAtwWhbFEYawcPwkYJhW1YcIxTEq2XweenUcVxs3X62fIVDjGT7l6q+5hLCN7CmOsO39mXabEHPtsHcpbPs7Wr4JW5zItr5+97948bO97Nn7jsqFQj+vd90V9KIyPf54rjAC3JZ71MkRhrBxfGAH2OrYw/uR4tiqMALdFYSxRGCsmNcAZKIwKo8IIcFMUxhKFsWJSA5yBwqgwKowAN0VhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYK/HHpd91Dy9bywBOFH+4/1n/4XrP1vjD/R9W981lAFwfhbFEYayY1ABnoDAqjAojwE1RGEsUxopJDXAGCqPCqDAC3BSFsURhXOt/kK/3v2X64R6TnfT624fublp/17K77uFtWlZNGHct2z6m1auy7MWrVbXs3Zu7w5Y5j5OP9fLncZ4xP/k8ruzeuZXzuF/l14vpmM5y75x6Hk8/5vN1Jmd9tp7p3jnpesxen/gPkwDXLp7XMkRhrMQPdz/IgSfmE8Zn/2zti6pPGAFuhsJYojBWTGqAM1AYFUaFEeCmKIwlCmPFpAY4A4VRYVQYAW6KwliiMAIAACQKY4nCCAAAkCiMJQojAABAojCWKIwAAACJwliiMAIAACQKY4nCCAAAkCiMJQojAABAojCWKIwAAACJwliiMFbij0s/5z+uDZxF/OH+tw/dXWvZs+DZGn+4/92bu+YyAK6PwliiMFZMaric+9UHE8gkJtQfVvfNZU9l15if9XqcpTDedQ9vP3QfbqKIXtmz9dWq/5mzetVYdiYKI8BtURhLFMbKCZOazcRjUk14NxO6afm77uFlWbefII/LFiZ9MYmt1pvvb2Oa+Ow8nji/tGw61/nrGwdP3uvzrCdhZdsHT872neMhYoIe683PYdr2hSav1bnU1/+wgrIZv+r+mN1Xx5Ss6njSGOwd8/oeqY976b6a3/8bC/d6XRgb9+Sh5zk/l7Te6YXxEWMeFMb19bzQ91wv9ld/v1U298hRz5RHUhgBbkv8nJAhCmPlsZOaepKyNUGISco40Yz/nSZ69WQ5v7baPfGp9jk//phQlnVjQpwnSLsmMIeVmRD7XHhvX9pi/8N7Tp+c1eO63/D+1aoe0348Y8z7yeIFJq/T+eevy373j/FQCFbreyDfK7HeoSWoVt8f8+3U8pgPx1H2sTmuzfWM7Rx6X7Xu8/ayY6/5qD7H1vfA0rHtW3bamG+cpTDekvl1ObdT75/z2fV9AcD1URhLFMbKIyc1s0Iw/Ffs1qS7nnCPX1clZtrW7olPPcnebGf8elaM+vdOX8d2F0rc/Dx2ySV4UXtfw/HEeQ+WJlP1Oe43TuYX11sqjP15l+PJx9sXhoVli7bGZru8rF4NYzNstz6m6fhjO1PZqLfRO+gaNFTbrdVjt/19EcvH69W/95D7qnEvD+umsa32uXzfL1+r3d8Du8Z8edkTjHkc7wmFsb7v0jXoz2vz+vw4NseW153GZ3Mc92ncq++7vN28XmPZ0vdrW4xrOv5DzK7x1r06Wz4eTz1mo3wtx9ca9+JsH7Gtcp753jj2/OvvGQCuXzzrZYjCWDlhUrPWnJiN0qSmLIv9jJOVYRIyTFTH14ZJzfD+/Ppce9l0PK0J6jTpW9rmfJK02/Deh/4clrc7nuP89Sze0xr7XeffEOe3Oe9+Atia1PdjMN/XfP9Lx7N26OS/v/ZpG5uxH8dhuE7l3Kpxz+umc9p63zgBPuR4Zpav83zM8/04Ll/vM4/tAffV/HrMJ+j18s0+Jnm7+6/VMLZrs3HZNeb7lj1qzA+9Z5L+ePas07zHZ/dZdf9snkfTuczvszyO/bJxPOKcl6/tftvX6FgxHtM5bc5j+ZkS+9t1vK3l89fy1/PzP3484lq1v98AuEbxs1SGKIyVx05qYv3ZRG2ccFQTtc1E5FWekJXJST2xyJOW2vZkcTOR3bw2TIDL+fTvryaHjQlXnkBONttdv39Qls/3UU1OJ7NxGW2Oodg+z+aEeLO9ab1pf/H67Hy31l2bT4yn19I2e+V4hrHLy2bnnJblSWG13uqhmmTWJWSznf54Z5PReL0a03z+6/e9Gdcbls+PtTWp7t+zUEaa47a5f4dtrtb7XPiEcTMW2/uc38fDPZXf19xvXjbbR23c9u7vgeUx371s35jvFeO3MN5t8/Fqa47Z1v2SNL+/B7Gt6vxn12gYy9kYHaz+3jxMHvN637vulcG+8Wsvr8YgX//q/i9a31tLtscXgGsWz3kZojBWTpnU1PKkoDkB7SdyYwFL+5omctuTpEmeIPXvn014tiaDecJ3yAR9eM8xk5qtc2xOSIdzqidX89caE7jWOe7Qn08er8lsG3Ed5sdYlYOZ+XE0z/EQ9f21WFD642udR3uCeuxEtB+nnYVi/5jHsR9+X23KRuNe27feJI/53muVr029n8Ux37Ns7tgx74/rxgtjfl9/Py5dg6b63j/E/J7J12fnvdLbN34Ly9N1iv1N53709dt29D0DwGcVP+tkiMJYOX5SU4v168lpntT0k5zNpGM+4Zm/t2hPbJrv7yeD+b35eLbL4NY2+qJy5PnPJqftiVw9Lr3Zsfbrzc5zeUwO0z6WtdZ59sezPTnuzd7fH9fR90l7/MvX7cl5b1cBOPKa9ce+Y+J7yJjn+/ig+2rrvmy8rz+P5X1X7911rXZ+DwzbWRrzXcsqR455L45rx7i3bI1jQ/Me33W/9OOzcOzz89p1nkefT1yHY8Zsdl9trnn99fY9Vey4fr32czXcr+L19fLq/Ib7KN/nx4pr9Zj1AbgshbFEYawcO6nZTOrWxz6YT0CGSUtZXm+7WndxYtiY2OyaLI0T7416gjJMeqbl1YRoNkE7QnUejUnWtKxXjrs+//rXNfdPCPfbmkzPxqaXj3e+fFpWX8fh32wecp/U680nr/W9s2Ps47iWjrMa7z02k+68zzAd144x78dyXGfrXt11X23Os3l/p/VinTiv6X2zbc7XX7xW28vyuO4a853X49QxH8XYHr3e8vOjuh6jcYziWJf21V/j5Xu33m6+F+bfy8d+b8b6xz1b6+tY/xr09vLG989s/WHf8/MIs3PZrLdVNre+f447H4UR4LbEs16GKIyVEyY1APucVBh/SjxbFUaA26IwliiMFZMa4AwURoVRYQS4KQpjicJYMakBzkBhVBgVRoCbojCWKIwAAACJwliiMAIAACQKY4nCCAAAkCiMJQojAABAojCWKIwAAACJwliiMAIAACQKY4nCCAAAkCiMJQojAABAojCWKIyV+OPS77qHl61lACeKP9z/rP9wvWdr/OH+D6v75jIAro/CWKIwVkxqgDNQGBVGhRHgpiiMJQpjxaQGOAOFUWFUGAFuisJYojCu9T/I1/vfMv1wj8lOev3tQ3c3rb9r2V338DYtqyaMu5ZtH9PqVVn24tWqWvbuzd1hy5zHycd6+fM4z5iffB5Xdu/cynncr/LrxXRMZ7l3Tj2Ppx/z+TqTsz5bz3TvnHQ9Zq9P/IdJgGsXz2sZojBW4oe7H+TAE/MJ47N/tvZF1SeMADdDYSxRGCsmNcAZKIwKo8IIcFMUxhKFsWJSA5yBwqgwKowAN0VhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYAQAAEoWxRGEEAABIFMYShREAACBRGEsURgAAgERhLFEYAQAAEoWxRGEEAABIFMaSqymM79+/77744ovmBQMAALiE6CTRTWTI1RTGH374ofvqq6+aFw0AAOASopNEN5EhV1MYP3361Df5uEA+aQQAAC4pOkh0kegk0U1kyNUUxkhcmGjzcZHi94YBAAAuITpIdBFlsc5VFUYRERERERG5niiMIiIiIiIi0ozCKCIiIiIiIs0ojCIiIiIiItKMwigiIiIiIiLNKIwiIiIiIiLSjMIoIiIiIiIizSiMIiIiIiIi0ozCKCIiIiIiIs0ojCIiIiIiItKMwigiIiIiIiLNKIwiIiIiIiLSjMIoIiIiIiIizSiMIiIiIiIi0ozCKCIiIiIiIs0ojCIiIiIiItKMwigiIiIiIiLNKIwiIiIiIiLSSNf9P225twIAJbfAAAAAAElFTkSuQmCC)

# 三、Glance基本概念
1、Image identifiers
Image使用URI作为唯一标识，URL符合以下格式：
<Glance Server Location>/images/<ID>
其中Glance Server Location 是镜像的所在位置，ID是镜像在Glance的唯一标识

2、Glance Image Statuses
glance image 共有六种状态如下所示：

镜像状态   | 描述
-------- | -----|
queued | 标识该镜像ID已经被保留，但是镜像还未上传
saving | 标识镜像正在被上传
active | 标识镜像在Glance中完全可用
killed | 标识镜像上传过程中出错，镜像完全不可用
deleted | Glance已经保存了镜像的信息，但是无法继续使用。在此状态下的镜像稍后将会被自动清除
pending_delete | 类似于deleted，区别在于Glance还没有移除镜像数据。在此状态下的镜像是可以被恢复的

3、状态转换关系图如下所示
![Image.png](https://img.hacpai.com/file/2019/12/Image-ec006e31.png)


4、Task Statuses

任务状态   | 描述
-------- | -----|
pending | 在Glance中保留task identifier。但此时还没有进程开始执行
processing | 任务已被底层执行者选中，并且后端Glance根据任务类型开始执行对应的逻辑操作
success | 表示该任务已经成功运行
killed | 表示在任务的执行过程中发生了一个错误，并且它不能继续执行下去

5、磁盘和容器格式

虚拟机镜像的磁盘格式是底层磁盘镜像的格式，其中包括：raw vhd vmdk vdi iso qcow2 aki ari ami

container格式表示虚拟机镜像是否在一个包括虚拟机的metadata文件格式中，容器格式包括：ovf bare aki ari ami

# 四、Glance的组件跟架构
Glance架构图如下图所示：
![Image2.png](https://img.hacpai.com/file/2019/12/Image2-17fcb65e.png)


Glance主要由三部分构成：glance-api，glance-registry和image store

组件   | 功能描述
-------- | -----|
glance-api | 接收REST API请求，然后通过其他模块来完成诸如镜像的查找、获取、上传跟删除等操作，默认监听端口为9292
glance-registry | 用于提供镜像元数据相关的REST接口，通过glance-registry，可以向数据库中写入或获取镜像的各种数据，其默认监听端口为9191.Glance的数据库中有两张表，一张是image表，一张是image property表。Image表保存了镜像格式、大小等信息；image property表则主要保存镜像的定制化信息。
image store | 一个存储的接口层，通过这个接口，glance可以获取镜像，支持的存储有Amazon的S3,、OpenStack本身的swift，还有诸如ceph，sheepdog，GlusterFS等分布式存储


# 五、镜像缓存机制
Glance中的镜像文件不关用什么样的方式存储，都存储在server端，用户在创建实例前先要从server端获取相应镜像，再到本地根据配置进行相关的处理。有些镜像文件非常的大，在从服务端传到客户端要花费大量的时间，使实例的启动变得非常慢，对于一些特定的应用来说会比较吃力，如果利用Glance的缓存机制，预先通过命令将特定的镜像进行缓存，缓存到需要的计算节点上会有很好的效果。对镜像进行缓存变相的增加了镜像存储的可靠性。

本地缓存的另一个好处就是，你可以通过他实现镜像的base imag的功能。Glance的缓存服务是需要在配置文件中进行配置开启的。glance缓存还提供了缓存，删除，根据配置的过期时间删除等众多的功能。

# 六、Glance常用命令
  image add project       Associate project with image
  image create              Create/upload an image
  image delete              Delete image(s)
  image list                  List available images
  image remove project  Disassociate project with image
  image save                Save an image locally
  image set                  Set image properties
  image show               Display image details
  image unset               Unset image tags and properties
